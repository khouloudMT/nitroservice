import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String id;
  final String name;
  final String email;
  final String? phone;
  final bool isPremium;
  final DateTime? premiumEndDate;
  final DateTime createdAt;

  UserModel({
    required this.id,
    required this.name,
    required this.email,
    this.phone,
    this.isPremium = false,
    this.premiumEndDate,
    required this.createdAt,
  });

  // From Firestore
  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return UserModel(
      id: doc.id,
      name: data['name'] ?? '',
      email: data['email'] ?? '',
      phone: data['phone'],
      isPremium: data['isPremium'] ?? false,
      premiumEndDate: data['premiumEndDate'] != null
          ? (data['premiumEndDate'] as Timestamp).toDate()
          : null,
      createdAt: (data['createdAt'] as Timestamp).toDate(),
    );
  }

  // To Firestore
  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'phone': phone,
      'isPremium': isPremium,
      'premiumEndDate': premiumEndDate,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }
}