import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/service_provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../widgets/service_card.dart';
import '../../widgets/loading_widget.dart';

class ServicesListScreen extends StatefulWidget {
  @override
  _ServicesListScreenState createState() => _ServicesListScreenState();
}

class _ServicesListScreenState extends State<ServicesListScreen> {
  String _selectedCategory = 'Tous';
  
  final List<String> _categories = [
    'Tous',
    'Entretien',
    'Réparation',
    'Diagnostic',
    'Électrique',
    'Pneumatique',
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<ServiceProvider>(context, listen: false).loadServices();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppStrings.services),
        actions: [
          IconButton(
            icon: Icon(Icons.filter_list),
            onPressed: _showFilterDialog,
          ),
        ],
      ),
      body: Column(
        children: [
          // Barre de recherche
          Padding(
            padding: EdgeInsets.all(16),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Rechercher un service...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onChanged: (value) {
                Provider.of<ServiceProvider>(context, listen: false)
                    .searchServices(value);
              },
            ),
          ),
          
          // Filtres par catégorie
          Container(
            height: 50,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.symmetric(horizontal: 16),
              itemCount: _categories.length,
              itemBuilder: (context, index) {
                final category = _categories[index];
                final isSelected = category == _selectedCategory;
                
                return Padding(
                  padding: EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(category),
                    selected: isSelected,
                    onSelected: (selected) {
                      setState(() {
                        _selectedCategory = category;
                      });
                      Provider.of<ServiceProvider>(context, listen: false)
                          .filterByCategory(category);
                    },
                    selectedColor: AppColors.primary,
                    labelStyle: TextStyle(
                      color: isSelected ? Colors.white : AppColors.textPrimary,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                );
              },
            ),
          ),
          
          SizedBox(height: 8),
          
          // Liste des services
          Expanded(
            child: Consumer<ServiceProvider>(
              builder: (context, serviceProvider, child) {
                if (serviceProvider.isLoading) {
                  return LoadingWidget(message: 'Chargement des services...');
                }

                if (serviceProvider.errorMessage != null) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.error_outline, size: 60, color: AppColors.error),
                        SizedBox(height: 16),
                        Text(
                          serviceProvider.errorMessage!,
                          style: TextStyle(color: AppColors.error),
                        ),
                        SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: () => serviceProvider.loadServices(),
                          child: Text('Réessayer'),
                        ),
                      ],
                    ),
                  );
                }

                final services = serviceProvider.services;

                if (services.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.inbox, size: 60, color: Colors.grey),
                        SizedBox(height: 16),
                        Text(
                          'Aucun service disponible',
                          style: TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                  );
                }

                return RefreshIndicator(
                  onRefresh: () => serviceProvider.loadServices(),
                  child: ListView.builder(
                    padding: EdgeInsets.all(16),
                    itemCount: services.length,
                    itemBuilder: (context, index) {
                      final service = services[index];
                      return Hero(
                        tag: 'service-${service.id}',
                        child: ServiceCard(
                          service: service,
                          onTap: () {
                            Navigator.pushNamed(
                              context,
                              '/service-detail',
                              arguments: service,
                            );
                          },
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showFilterDialog() {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          padding: EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Filtres',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20),
              ListTile(
                leading: Icon(Icons.sort),
                title: Text('Prix croissant'),
                onTap: () {
                  // TODO: Implement sorting
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(Icons.sort),
                title: Text('Prix décroissant'),
                onTap: () {
                  // TODO: Implement sorting
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(Icons.star),
                title: Text('Les plus populaires'),
                onTap: () {
                  // TODO: Implement sorting
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        );
      },
    );
  }
}